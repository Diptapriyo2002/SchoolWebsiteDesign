
-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `phone` int(30) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `usertype` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `phone`, `email`, `usertype`, `password`) VALUES
(1, 'admin', 629723121, 'admin@gmail.com', 'admin', '1234'),
(2, 'student', 954789643, 'student@gmail.com', 'student', '12345'),
(3, 'dipta ghosh', 947483647, 'dipta2002@gmail.com', 'student', '14524'),
(4, 'Deba Roy', 2147483647, 'deba@145gmail.com', 'student', '4568');
