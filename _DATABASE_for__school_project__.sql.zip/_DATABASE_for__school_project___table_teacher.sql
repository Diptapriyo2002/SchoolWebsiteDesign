
-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

DROP TABLE IF EXISTS `teacher`;
CREATE TABLE `teacher` (
  `id` int(20) NOT NULL,
  `name` varchar(38) DEFAULT NULL,
  `description` varchar(50) DEFAULT NULL,
  `image` varchar(38) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`id`, `name`, `description`, `image`) VALUES
(1, 'Mr. Nolen Davis', 'A literature enthusiast man.', 'image/teacher2.jpg'),
(2, 'Mr. John Smith', 'A passionate math educator.', 'image/teacher3.jpg'),
(11, 'Mr. Ralph Johnson', 'A passionate science educator.', 'image/teacher1.jpg');
